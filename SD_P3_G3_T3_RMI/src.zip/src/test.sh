#!/bin/bash
cd src/
./build_and_deploy.sh
