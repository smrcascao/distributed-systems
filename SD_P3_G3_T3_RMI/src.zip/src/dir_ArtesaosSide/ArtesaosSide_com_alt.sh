java -Djava.rmi.server.codebase="file:///home/ruib/Teaching/java/exemplos/Barbeiros_Sonolentos/rmi_CS/Barbeiros_Sonolentos_rmi_CS_tipo_2_est/dir_clientSide/"\
     -Djava.rmi.server.useCodebaseOnly=false\
     clientSide.ClientSleepingBarbers
