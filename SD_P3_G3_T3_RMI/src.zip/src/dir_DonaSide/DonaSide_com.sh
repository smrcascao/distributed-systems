java DonaSide.runDona
