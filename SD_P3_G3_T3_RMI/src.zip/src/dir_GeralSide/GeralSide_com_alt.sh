java -Djava.rmi.server.codebase="file:///home/ruib/Teaching/java/exemplos/Barbeiros_Sonolentos/rmi_CS/Barbeiros_Sonolentos_rmi_CS_tipo_2_est/dir_serverSide/"\
     -Djava.rmi.server.useCodebaseOnly=false\
     -Djava.security.policy=java.policy\
     serverSide.ServerSleepingBarbers
