#!/bin/bash
cd src/
./build_and_deploy.sh
clear
cd dir_ArtesaosSide/
ArtesaosSide_com.sh