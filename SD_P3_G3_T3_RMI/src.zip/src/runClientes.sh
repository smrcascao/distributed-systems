#!/bin/bash
cd src/
./build_and_deploy.sh
clear
cd dir_ClientesSide/
ClientesSide_com.sh