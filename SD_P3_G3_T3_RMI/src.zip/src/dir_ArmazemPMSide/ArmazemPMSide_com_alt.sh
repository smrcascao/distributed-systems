java -Djava.rmi.server.codebase="file:///home/sd0303/SD_P3_G3_T3_RMI/dir_ArmazemPMSide/"\
     -Djava.rmi.server.useCodebaseOnly=false\
     -Djava.security.policy=java.policy\
     serverSide.ServerSleepingBarbers
