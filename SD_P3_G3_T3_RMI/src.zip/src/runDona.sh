#!/bin/bash
cd src/
./build_and_deploy.sh
clear
cd dir_DonaSide/
DonaSide_com.sh