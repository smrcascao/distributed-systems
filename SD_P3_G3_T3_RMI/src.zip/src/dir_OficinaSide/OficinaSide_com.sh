java -Djava.rmi.server.codebase="http://l040101-ws11.ua.pt/sd0303/classes/"\
     -Djava.rmi.server.useCodebaseOnly=true\
     -Djava.security.policy=java.policy\
     OficinaSide.runOficina
