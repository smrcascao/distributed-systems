java -Djava.rmi.server.codebase="file:///home/ruib/Teaching/java/exemplos/Back_Engine_Alunos/dir_registry/"\
     -Djava.rmi.server.useCodebaseOnly=false\
     -Djava.security.policy=java.policy\
     registry.ServerRegisterRemoteObject
