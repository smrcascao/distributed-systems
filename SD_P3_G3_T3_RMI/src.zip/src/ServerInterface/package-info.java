/**
 *  Interfaces remotas das regioes partilhadas.<p>
 *  Solução do Problema Obrigatorio 3 que implementa o modelo cliente-servidor
 *  de tipo 2 (replicação do servidor).
 *  A comunicação baseia-se na invocação remota de métodos (RMI).
 */
package ServerInterface;
