/**
 * Estados das entidades activas.
 * Contem Enums com as listas de estados das Entidades Dona, Artesao e Cliente
 */
package States;
