/**
 * Relogio vectorial usado para possibilitar a ordenaçao causal de operaçoes sobre o Repositorio Geral (descriçao detalhada do estado interno do problema).
 */
package VectorTime;
